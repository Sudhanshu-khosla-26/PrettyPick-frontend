// import { View, Text, StyleSheet } from 'react-native';

// export default function HomeTabs() {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.text}>Welcome to Pretty Pink 👗</Text>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1, justifyContent: 'center', alignItems: 'center' },
//   text: { fontSize: 22, fontWeight: 'bold' },
// });
// app/index.tsx
import React, { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';

export default function IndexScreen() {
  const router = useRouter();

  useEffect(() => {
    const timer = setTimeout(() => {
      const isLoggedIn = false; // simulate auth status
      if (isLoggedIn) {
        router.replace('./tabs');
      } else {
        router.replace('/onboarding/welcome');
      }
    }, 100); // ✅ delay slightly to let RootLayout mount

    return () => clearTimeout(timer);
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color="#ff66b3" />
    </View>
  );
}

