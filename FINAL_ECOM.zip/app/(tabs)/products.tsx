import React from 'react';
import {
  View,
  Text,
  FlatList,
  Image,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { useRouter } from 'expo-router';

const products = [
  {
    id: '1',
    name: 'Floral Summer Dress',
    price: 1200,
    image: require('../../assets/images/dress1.jpg'),
  },
  {
    id: '2',
    name: 'Casual Kurti',
    price: 999,
    image: require('../../assets/images/kurti.jpg'),
  },
  {
    id: '3',
    name: 'Pink Hoodie',
    price: 1500,
    image: require('../../assets/images/hoodie.jpg'),
  },
  {
    id: '4',
    name: 'Slim Fit Top',
    price: 1600,
    image: require('../../assets/images/fir.jpg'),
  },
  {
    id: '5',
    name: 'Western Top',
    price: 1100,
    image: require('../../assets/images/sec.jpg'),
  },
  {
    id: '6',
    name: 'Crop Top',
    price: 800,
    image: require('../../assets/images/thir.jpg'),
  },
];

const ProductList = () => {
  const router = useRouter();

  const renderItem = ({ item }: { item: typeof products[0] }) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => router.push(`./products/${item.id}`)} // ✅ Correct syntax
    >
      <Image source={item.image} style={styles.image} />
      <Text style={styles.name}>{item.name}</Text>
      <Text style={styles.price}>₹{item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>🛍️ Explore Products</Text>
      <FlatList
        data={products}
        renderItem={renderItem}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.list}
      />
    </View>
  );
};

export default ProductList;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    paddingTop: 20,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 16,
    marginBottom: 12,
  },
  list: {
    paddingHorizontal: 12,
  },
  card: {
    flex: 1,
    margin: 8,
    backgroundColor: '#fdfdfd',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    elevation: 3,
  },
  image: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 10,
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'center',
  },
  price: {
    fontSize: 13,
    color: '#555',
    marginTop: 4,
  },
});

      