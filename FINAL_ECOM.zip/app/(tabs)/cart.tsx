import React, { useState } from 'react';
import { View, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const initialItems = [
  {
    id: '1',
    title: 'Slim Fit Top',
    price: 1600,
    quantity: 1,
    image: require('../../assets/images/fir.jpg'),
  },
  {
    id: '2',
    title: 'Western Top',
    price: 1100,
    quantity: 2,
    image: require('../../assets/images/sec.jpg'),
  },
];

const CartScreen = () => {
  const [cartItems, setCartItems] = useState(initialItems);

  const increaseQty = (id: string) => {
    setCartItems(prev =>
      prev.map(item => item.id === id ? { ...item, quantity: item.quantity + 1 } : item)
    );
  };

  const decreaseQty = (id: string) => {
    setCartItems(prev =>
      prev.map(item =>
        item.id === id && item.quantity > 1
          ? { ...item, quantity: item.quantity - 1 }
          : item
      )
    );
  };

  const deleteItem = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const renderItem = ({ item }: { item: typeof initialItems[0] }) => (
    <View style={styles.item}>
      <Image source={item.image} style={styles.image} />
      <View style={styles.details}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.price}>₹{item.price} x {item.quantity}</Text>

        <View style={styles.controls}>
          <TouchableOpacity onPress={() => decreaseQty(item.id)}>
            <Ionicons name="remove-circle-outline" size={24} color="#ff69b4" />
          </TouchableOpacity>
          <Text style={styles.qty}>{item.quantity}</Text>
          <TouchableOpacity onPress={() => increaseQty(item.id)}>
            <Ionicons name="add-circle-outline" size={24} color="#ff69b4" />
          </TouchableOpacity>

          <TouchableOpacity onPress={() => deleteItem(item.id)} style={styles.deleteBtn}>
            <Ionicons name="trash-outline" size={24} color="#ff3b3b" />
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {cartItems.length === 0 ? (
        <View style={styles.empty}>
          <Text style={styles.emptyText}>🛒 Your cart is empty!</Text>
        </View>
      ) : (
        <>
          <FlatList
            data={cartItems}
            renderItem={renderItem}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.list}
          />
          <View style={styles.footer}>
            <Text style={styles.total}>Total: ₹{total}</Text>
            <TouchableOpacity style={styles.checkoutButton}>
              <Text style={styles.checkoutText}>Checkout</Text>
            </TouchableOpacity>
          </View>
        </>
      )}
    </View>
  );
};

export default CartScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  list: {
    padding: 16,
  },
  item: {
    flexDirection: 'row',
    marginBottom: 20,
    backgroundColor: '#f9f9f9',
    borderRadius: 12,
    padding: 10,
    elevation: 2,
  },
  image: {
    width: 70,
    height: 70,
    borderRadius: 10,
  },
  details: {
    marginLeft: 12,
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: '600',
  },
  price: {
    fontSize: 14,
    color: '#555',
    marginVertical: 4,
  },
  controls: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  qty: {
    marginHorizontal: 10,
    fontSize: 16,
    fontWeight: '600',
  },
  deleteBtn: {
    marginLeft: 16,
  },
  footer: {
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    padding: 16,
    backgroundColor: '#fff',
  },
  total: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  checkoutButton: {
    backgroundColor: '#ff69b4',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  checkoutText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16,
  },
  empty: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    color: '#999',
  },
});
