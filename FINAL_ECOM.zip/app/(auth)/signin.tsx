// import React, { useState } from 'react';
// import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
// import { useRouter } from 'expo-router';
// import React, { useState } from 'react'; // ✅ must have

// const SignInScreen = () => {
//   const router = useRouter();
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   const handleSignIn = () => {
//     if (!email || !password) {
//       Alert.alert('Error', 'Please fill in both fields');
//       return;
//     }
//     Alert.alert('Signed In', `Welcome ${email}`);
//     router.push('/(tabs)');
//   };

//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>Welcome Back!</Text>

//       <TextInput
//         placeholder="Email"
//         placeholderTextColor="#999"
//         style={styles.input}
//         keyboardType="email-address"
//         autoCapitalize="none"
//         value={email}
//         onChangeText={setEmail}
//       />

//       <TextInput
//         placeholder="Password"
//         placeholderTextColor="#999"
//         style={styles.input}
//         secureTextEntry
//         value={password}
//         onChangeText={setPassword}
//       />

//       <TouchableOpacity onPress={() => Alert.alert('Forgot Password')}>
//         <Text style={styles.forgot}>Forgot Password?</Text>
//       </TouchableOpacity>

//       <TouchableOpacity style={styles.button} onPress={handleSignIn}>
//         <Text style={styles.buttonText}>Sign In</Text>
//       </TouchableOpacity>

//       <Text style={styles.footer}>
//         Don’t have an account?{' '}
//         <Text style={styles.link} onPress={() => router.push('./auth/signup')}>
//           Sign Up
//         </Text>
//       </Text>
//     </View>
//   );
// };

// export default SignInScreen;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     padding: 24,
//     justifyContent: 'center',
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: 'bold',
//     marginBottom: 32,
//     textAlign: 'center',
//   },
//   input: {
//     borderWidth: 1,
//     borderColor: '#ccc',
//     borderRadius: 8,
//     paddingHorizontal: 14,
//     paddingVertical: 12,
//     marginBottom: 16,
//     fontSize: 16,
//   },
//   forgot: {
//     color: '#888',
//     textAlign: 'right',
//     marginBottom: 24,
//   },
//   button: {
//     backgroundColor: '#ff69b4',
//     paddingVertical: 14,
//     borderRadius: 25,
//     alignItems: 'center',
//     marginBottom: 24,
//   },
//   buttonText: {
//     color: '#fff',
//     fontWeight: '600',
//     fontSize: 16,
//   },
//   footer: {
//     textAlign: 'center',
//     fontSize: 14,
//     color: '#444',
//   },
//   link: {
//     color: '#ff69b4',
//     fontWeight: '600',
//   },
// });
// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   StyleSheet,
//   KeyboardAvoidingView,
//   Platform,
// } from 'react-native';
// import { router } from 'expo-router';

// const SignInScreen = () => {
//   const [email, setEmail] = useState('');
//   const [password, setPassword] = useState('');

//   return (
//     <KeyboardAvoidingView
//       style={styles.container}
//       behavior={Platform.OS === 'ios' ? 'padding' : undefined}
//     >
//       <Text style={styles.title}>Welcome Back!</Text>

//       <TextInput
//         placeholder="Email"
//         placeholderTextColor="#999"
//         keyboardType="email-address"
//         value={email}
//         onChangeText={setEmail}
//         style={styles.input}
//       />
//       <TextInput
//         placeholder="Password"
//         placeholderTextColor="#999"
//         secureTextEntry
//         value={password}
//         onChangeText={setPassword}
//         style={styles.input}
//       />

//       <TouchableOpacity style={styles.button}>
//         <Text style={styles.buttonText}>Sign In</Text>
//       </TouchableOpacity>

//       <TouchableOpacity onPress={() => router.replace('./auth/signup')}>
//         <Text style={styles.link}>Don't have an account? Sign Up</Text>
//       </TouchableOpacity>
//     </KeyboardAvoidingView>
//   );
// };

// export default SignInScreen;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff',
//     justifyContent: 'center',
//     padding: 20,
//   },
//   title: {
//     fontSize: 32,
//     fontWeight: '700',
//     color: '#ff66b3',
//     marginBottom: 40,
//     textAlign: 'center',
//   },
//   input: {
//     height: 50,
//     borderColor: '#ff66b3',
//     borderWidth: 1,
//     borderRadius: 10,
//     paddingHorizontal: 15,
//     marginBottom: 20,
//     fontSize: 16,
//   },
//   button: {
//     backgroundColor: '#ff66b3',
//     paddingVertical: 15,
//     borderRadius: 10,
//     marginBottom: 15,
//   },
//   buttonText: {
//     color: '#fff',
//     textAlign: 'center',
//     fontWeight: '600',
//     fontSize: 16,
//   },
//   link: {
//     textAlign: 'center',
//     color: '#888',
//     textDecorationLine: 'underline',
//   },
// });
import React, { useState, useEffect } from 'react';
import {
  View, Text, TextInput, TouchableOpacity,
  StyleSheet, KeyboardAvoidingView, Platform
} from 'react-native';
import { useRouter } from 'expo-router';

const SignInScreen = () => {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [shouldNavigate, setShouldNavigate] = useState(false);

  useEffect(() => {
    if (shouldNavigate && router) {
      router.replace('./tabs'); // use absolute path
    }
  }, [shouldNavigate, router]);

  const handleSignIn = () => {
    console.log('Email:', email);
    console.log('Password:', password);
    setShouldNavigate(true);
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <Text style={styles.title}>Sign In</Text>
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <TouchableOpacity style={styles.button} onPress={handleSignIn}>
        <Text style={styles.buttonText}>Sign In</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => router.push('./auth/signup')}>
        <Text style={styles.link}>Don't have an account? Sign Up</Text>
      </TouchableOpacity>
    </KeyboardAvoidingView>
  );
};

export default SignInScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1, backgroundColor: '#fff0f5', padding: 24, justifyContent: 'center',
  },
  title: {
    fontSize: 28, fontWeight: 'bold', color: '#ff69b4', marginBottom: 32, textAlign: 'center',
  },
  input: {
    height: 50, backgroundColor: '#fff', borderRadius: 8, paddingHorizontal: 16,
    marginBottom: 16, borderWidth: 1, borderColor: '#ffb6c1',
  },
  button: {
    backgroundColor: '#ff69b4', paddingVertical: 14, borderRadius: 8, marginBottom: 12,
  },
  buttonText: {
    color: '#fff', fontWeight: '600', textAlign: 'center', fontSize: 16,
  },
  link: {
    color: '#ff69b4', textAlign: 'center', fontWeight: '500', marginTop: 8,
  },
});
