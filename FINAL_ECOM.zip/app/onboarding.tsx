// import React from 'react';
// import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
// import { useRouter } from 'expo-router';

// const OnboardingScreen = () => {
//   const router = useRouter();

//   return (
//     <View style={styles.container}>
//       <Image
//         source={require('../assets/images/onboarding.png')}
//         style={styles.image}
//         resizeMode="contain"
//       />
//       <Text style={styles.title}>Welcome to Pretty Pink</Text>
//       <Text style={styles.subtitle}>
//         Discover fashion that defines your personality. Let’s get started!
//       </Text>

//       <TouchableOpacity style={styles.button} onPress={() => router.push('/signin')}>
//         <Text style={styles.buttonText}>Continue</Text>
//       </TouchableOpacity>
//     </View>
//   );
// };

// export default OnboardingScreen;

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#fff0f5',
//     alignItems: 'center',
//     justifyContent: 'center',
//     padding: 24,
//   },
//   image: {
//     width: '100%',
//     height: 300,
//     marginBottom: 20,
//   },
//   title: {
//     fontSize: 28,
//     fontWeight: 'bold',
//     color: '#ff69b4',
//     textAlign: 'center',
//     marginBottom: 10,
//   },
//   subtitle: {
//     fontSize: 16,
//     textAlign: 'center',
//     color: '#555',
//     marginBottom: 30,
//     paddingHorizontal: 10,
//   },
//   button: {
//     backgroundColor: '#ff69b4',
//     paddingVertical: 12,
//     paddingHorizontal: 36,
//     borderRadius: 25,
//   },
//   buttonText: {
//     color: '#fff',
//     fontSize: 16,
//     fontWeight: '600',
//   },
// });
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ImageBackground } from 'react-native';
import { useRouter } from 'expo-router';

export default function Onboarding() {
  const router = useRouter();

  return (
    <ImageBackground
      source={require('../assets/images/onboarding.png')} // Replace with your image
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <Text style={styles.title}>Welcome to Pretty Pink!</Text>
        <Text style={styles.subtitle}>Your style journey starts here.</Text>

        <TouchableOpacity
          style={styles.button}
          onPress={() => router.push('/signin')}
        >
          <Text style={styles.buttonText}>Sign In</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: '#fff' }]}
          onPress={() => router.push('/signup')}
        >
          <Text style={[styles.buttonText, { color: '#ff69b4' }]}>Sign Up</Text>
        </TouchableOpacity>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
    justifyContent: 'center',
  },
  overlay: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  title: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 10,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 18,
    color: '#ffe4f2',
    marginBottom: 40,
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#ff69b4',
    paddingVertical: 14,
    paddingHorizontal: 36,
    borderRadius: 25,
    marginBottom: 16,
    width: '80%',
  },
  buttonText: {
    fontSize: 16,
    color: '#fff',
    textAlign: 'center',
    fontWeight: '600',
  },
});
