// app/index.tsx
import React, { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';

export default function IndexRedirect() {
  const router = useRouter();

  useEffect(() => {
    // 🔁 Replace this logic with Firebase/Auth check
    const isLoggedIn = false;

    if (isLoggedIn) {
      router.replace('./tabs'); // go to home tabs
    } else {
      router.replace('/onboarding/welcome'); // go to welcome
    }
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ActivityIndicator size="large" color="#ff66b3" />
    </View>
  );
}
