// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   Image,
//   StyleSheet,
//   TouchableOpacity,
//   ScrollView,
// } from 'react-native';
// import { Ionicons } from '@expo/vector-icons';
// import { useLocalSearchParams } from 'expo-router';

// const dummyProduct = {
//   id: '1',
//   title: 'Slim Fit Pink Top',
//   price: 799,
//   description: 'A beautifully tailored top for everyday style and comfort.',
//   image: require('../../assets/images/fir.jpg'),
// };

// export default function ProductDetail() {
//   const { id } = useLocalSearchParams();
//   const [quantity, setQuantity] = useState(1);
//   const [isWishlisted, setIsWishlisted] = useState(false);

//   const increment = () => setQuantity((q) => q + 1);
//   const decrement = () => setQuantity((q) => (q > 1 ? q - 1 : 1));

//   return (
//     <ScrollView style={styles.container}>
//       <Image source={dummyProduct.image} style={styles.image} />

//       <View style={styles.headerRow}>
//         <Text style={styles.title}>{dummyProduct.title}</Text>
//         <TouchableOpacity onPress={() => setIsWishlisted(!isWishlisted)}>
//           <Ionicons
//             name={isWishlisted ? 'heart' : 'heart-outline'}
//             size={28}
//             color="#ff66b3"
//           />
//         </TouchableOpacity>
//       </View>

//       <Text style={styles.price}>₹{dummyProduct.price}</Text>
//       <Text style={styles.description}>{dummyProduct.description}</Text>

//       <View style={styles.quantityContainer}>
//         <Text style={styles.label}>Quantity:</Text>
//         <View style={styles.quantitySelector}>
//           <TouchableOpacity onPress={decrement} style={styles.qtyBtn}>
//             <Text style={styles.qtyText}>-</Text>
//           </TouchableOpacity>
//           <Text style={styles.qtyNumber}>{quantity}</Text>
//           <TouchableOpacity onPress={increment} style={styles.qtyBtn}>
//             <Text style={styles.qtyText}>+</Text>
//           </TouchableOpacity>
//         </View>
//       </View>

//       <TouchableOpacity style={styles.addToCart}>
//         <Text style={styles.addToCartText}>Add to Cart</Text>
//       </TouchableOpacity>
//     </ScrollView>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     backgroundColor: '#fff',
//     flex: 1,
//     padding: 16,
//   },
//   image: {
//     width: '100%',
//     height: 300,
//     borderRadius: 12,
//     marginBottom: 16,
//   },
//   headerRow: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     flex: 1,
//     marginRight: 8,
//   },
//   price: {
//     fontSize: 20,
//     color: '#ff66b3',
//     fontWeight: '600',
//     marginVertical: 8,
//   },
//   description: {
//     fontSize: 16,
//     color: '#555',
//     marginBottom: 16,
//   },
//   quantityContainer: {
//     marginVertical: 16,
//   },
//   label: {
//     fontSize: 16,
//     fontWeight: '500',
//     marginBottom: 8,
//   },
//   quantitySelector: {
//     flexDirection: 'row',
//     alignItems: 'center',
//   },
//   qtyBtn: {
//     backgroundColor: '#ff66b3',
//     borderRadius: 20,
//     padding: 10,
//   },
//   qtyText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 18,
//   },
//   qtyNumber: {
//     marginHorizontal: 20,
//     fontSize: 18,
//     fontWeight: '600',
//   },
//   addToCart: {
//     backgroundColor: '#ff69b4',
//     paddingVertical: 14,
//     borderRadius: 10,
//     alignItems: 'center',
//     marginTop: 20,
//   },
//   addToCartText: {
//     color: '#fff',
//     fontWeight: 'bold',
//     fontSize: 16,
//   },
// });
import React, { useState } from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

type Product = {
  id: string;
  name: string;
  price: number;
  image: any;
};

const productData: Record<string, Product> = {
  '1': {
    id: '1',
    name: 'Floral Summer Dress',
    price: 1200,
    image: require('../../assets/images/dress1.jpg'),
  },
  '2': {
    id: '2',
    name: 'Casual Kurti',
    price: 999,
    image: require('../../assets/images/kurti.jpg'),
  },
  '3': {
    id: '3',
    name: 'Pink Hoodie',
    price: 1500,
    image: require('../../assets/images/hoodie.jpg'),
  },
  '4': {
    id: '4',
    name: 'Slim Fit Top',
    price: 1600,
    image: require('../../assets/images/fir.jpg'),
  },
  '5': {
    id: '5',
    name: 'Western Top',
    price: 1100,
    image: require('../../assets/images/sec.jpg'),
  },
  '6': {
    id: '6',
    name: 'Crop Top',
    price: 800,
    image: require('../../assets/images/thir.jpg'),
  },
};

export default function ProductDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const product = id ? productData[id] : null;

  const [quantity, setQuantity] = useState(1);
  const [wishlist, setWishlist] = useState(false);

  if (!product) {
    return (
      <View style={styles.center}>
        <Text>Product not found!</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Image source={product.image} style={styles.image} />

      <View style={styles.details}>
        <Text style={styles.title}>{product.name}</Text>
        <Text style={styles.price}>₹{product.price}</Text>

        <View style={styles.quantityContainer}>
          <TouchableOpacity
            style={styles.qtyButton}
            onPress={() => setQuantity(Math.max(1, quantity - 1))}
          >
            <Text style={styles.qtyText}>-</Text>
          </TouchableOpacity>
          <Text style={styles.qtyValue}>{quantity}</Text>
          <TouchableOpacity
            style={styles.qtyButton}
            onPress={() => setQuantity(quantity + 1)}
          >
            <Text style={styles.qtyText}>+</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity
          onPress={() => setWishlist(!wishlist)}
          style={styles.wishlistButton}
        >
          <Ionicons
            name={wishlist ? 'heart' : 'heart-outline'}
            size={28}
            color={wishlist ? 'red' : 'gray'}
          />
        </TouchableOpacity>

        <TouchableOpacity style={styles.addToCart}>
          <Text style={styles.cartText}>Add to Cart</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  image: {
    width: '100%',
    height: 320,
    resizeMode: 'cover',
  },
  details: {
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 10,
  },
  price: {
    fontSize: 18,
    color: '#666',
    marginBottom: 20,
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  qtyButton: {
    backgroundColor: '#eee',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 8,
  },
  qtyText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  qtyValue: {
    fontSize: 18,
    fontWeight: '600',
    marginHorizontal: 20,
  },
  wishlistButton: {
    alignSelf: 'flex-end',
    marginBottom: 30,
  },
  addToCart: {
    backgroundColor: '#ff69b4',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  cartText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
